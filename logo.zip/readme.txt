Hi! 

Thanks for purchasing on logogenie.net

-------------------------------------

YOUR VECTOR FOLDER

Before you open the files in your vector folder, make sure that you've intalled all the fonts provided in the "Font" folder

PC :

- Right click on the font file
- In the drop down menu, click on "Install"

MAC : 

- Double click on the font file
- Click on the install button


WHAT IS A VECTOR FILE USED FOR? (SVG & PDF)

Vector files are very useful as they can be rescaled to any size without any quality loss. 
You may have seen JPG or Bitmap images that have blurry edges & messy quality... 
A vector file never has that problem. Vector files are mathematically calculated so that 
they adapt themselves perfectly to the new size. Vector files are commonly used for printing.

--------------------------------------------------------------------

YOUR PRINT FOLDER

The files provided in this folder are suitable for high resolution printing ex: Business cards, Letterheads, Signs...
These files are 3000px large (using vectors files is recommended for optimum printing quality).

YOUR WEB FOLDER

The files provided in this folder are suitable for web usage: Website, Blogs, Social network profiles, Emails...
These files are 500px large.

SOCIAL NETWORK FOLDER (Logogenie option)

The files provided in the social network folder are designed for your Facebook, Twitter, LinkedIn... profiles

--------------------------------------------------------------------

We hope you've had a great experience on Logogenie!
If you have any other questions or having problems with your logo, 
drop us an email using our contact page or with support@logogenie.fr,
Our friendly staff will be happy to assist you.


The Logogenie team.